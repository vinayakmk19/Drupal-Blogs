<?php

namespace Drupal\blog_list\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class BlogListController extends ControllerBase
{

    public function blogPage()
    {
        $nodes = \Drupal::entityTypeManager()->getStorage('node')->loadByProperties(['type' => 'blogs']);

        $data = [];
        foreach ($nodes as $node) {
            $data[] = [
                'id' => $node->id(),
                'title' => $node->getTitle(),
                'description' => $node->get('field_description')->value,
                'created_date' => $node->get('field_created_date')->value,
                'active' => $node->get('field_active')->value,
            ];
        }

        return [
            '#theme' => 'blog_list_page',
            '#nodes' => $data,
            '#attached' => [
                'library' => [
                    'blog_list/datatables',
                ],
            ],
        ];
    }

    // Add this method to your BlogListController

    public function blogDetail($node_id) {
        // Load the blog node by ID
        $node = \Drupal::entityTypeManager()->getStorage('node')->load($node_id);
    
        // Check if the node exists and is of type 'blogs'
        if ($node && $node->getType() === 'blogs') {
            // Create an associative array to store the values
            $data = [
                'id' => $node->id(),
                'title' => $node->getTitle(),
                'description' => $node->get('field_description')->value,
                'created_date' => $node->get('field_created_date')->value,
                'active' => $node->get('field_active')->value,
            ];
    
            return [
                '#theme' => 'blog_detail_page',
                '#data' => $data, // Pass the data array to the template
            ];
        } else {
            throw new NotFoundHttpException(); // Handle not found
        }
    }
    
}
