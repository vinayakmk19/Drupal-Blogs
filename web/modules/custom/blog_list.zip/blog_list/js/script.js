jQuery(document).ready(function() {
    jQuery('#b-table').DataTable({
      paging: true,         // Enable pagination
      searching: true,      // Enable search box
      ordering: true,       // Enable column sorting
      responsive: true,     // Make the table responsive
      columns: [
        { title: "Title" },
        { title: "Description" },
        { title: "Created Date" },
        { title: "Active" }
      ]
    });
  });